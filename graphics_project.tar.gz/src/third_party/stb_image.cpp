#define STB_IMAGE_IMPLEMENTATION
#include <third_party/stb_image.h>
