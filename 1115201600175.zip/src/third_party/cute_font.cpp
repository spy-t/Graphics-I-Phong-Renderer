#define CUTE_FONT_IMPLEMENTATION
#include <cstdint>
#include <third_party/cute_font.h>
